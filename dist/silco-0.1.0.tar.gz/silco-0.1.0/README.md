# SILCO (**S**ystem **I**llustration & **L**ayout **Co**mposer)

Silco is a Python-first diagram toolkit built around a small microkernel. The core owns the document model, layout contracts, and plugin registry; renderers, styles, and presenters plug into that kernel. The default SVG renderer now uses the `diagrams` package with C4-flavored Graphviz output so the generated diagrams read like real system design documentation instead of custom-drawn boxes.

```python
from silco import diagram

d = (
    diagram("Checkout")
    .node("user", "User", kind="actor")
    .node("api", "API", kind="service", group="app")
    .node("db", "Orders DB", kind="database", group="data")
    .connect("user", "api", "HTTPS")
    .connect("api", "db", "SQL")
)

svg = d.to_svg(style="modern")
```

Runtime requirement: Graphviz must be installed and `dot` must be on `PATH`.

Built-ins are registered through the kernel on import. Styles, layouts, and optional renderers stay discoverable:

```python
from silco import kernel

kernel.names("layouts")      # ("dag", "grid")
kernel.names("renderers")    # ("svg", "mermaid", ...)
kernel.names("styles")       # ("modern", "uml")
kernel.discover()            # optional plugin discovery
```

Render the same diagram in different ways:

```python
svg = d.to_svg(style="uml", layout="dag", title=True)
mermaid = d.to_mermaid()
```

In IPython/Jupyter:

```python
%load_ext silco.plugins.ipython
d
```

Export as PDF with the optional CairoSVG-backed renderer plugin:

```bash
pip install "silco[pdf]"
```

```python
d.save_pdf("checkout.pdf")
pdf_bytes = d.to_pdf()
```

Plugin categories:

```python
kernel.categories()
kernel.names("renderers")
kernel.names("presenters")
```
